#ifndef _TIM2_DELAY_LIB_H_
#define _TIM2_DELAY_LIB_H_

void TIM2_init(void);
void delay_us(uint32_t n_usec);
void delay_ms(uint32_t n_msec);

#endif
